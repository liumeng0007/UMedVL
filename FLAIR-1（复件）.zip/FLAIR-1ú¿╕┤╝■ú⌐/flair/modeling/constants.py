
PATH_PRETRAINED_WEIGHTS = "./flair/modeling/flair_pretrained_weights/"

ID_FLAIR_RESNET_V1 = "flair_resnet.pth"
URL_ID_FLAIR_RESNET_V1 = "1l24_2IzwQdnaa034I0zcyDLs_zMujsbR"

""" Config file. Set all hyperparameters for ADAM Dataset. """

# ************************************************************************************ #
# ************************************ GPU SETTINGS ********************************** #
# ************************************************************************************ #
GPU_ID = "0, 1, 2, 3"  # The VISIBLE_DEVICES
GPU_TEST = "2"  # test GPU

# ************************************************************************************ #
# ****************************** DIRECTORY PATH SETTINGS ***************************** #
# ************************************************************************************ #
# PATH_SAVE = "/home/ubuntu/PycharmProjects/UML/exp_ispy/save"
# PATH_CHECKPOINTS = f"{PATH_SAVE}/checkpoints/"
# PATH_LOGFILE = f"{PATH_SAVE}/logs/"
# PATH_MODEL = f"{PATH_CHECKPOINTS}/Model_results/"
# SEG_RESULT_PATH_OF_TEST = "test/"
# ************************************************************************************ #
# ********************************** DATASET SETTINGS ******************************** #
# ************************************************************************************ #
# ISPY_ROOT_PATH = "E:/renkai/Joint_RK/Code/Data/I-SPY1/ISPY_Dataset_10"
ADAM_ROOT_PATH = "/home/ubuntu/桌面/UMLpaper_DATASET/ADAM/ADAM_for_train"
BATCH_SIZE = 4


# ************************************************************************************ #
# *********************************** MODEL SETTINGS ********************************* #
# ************************************************************************************ #
# for model structure
# PRETRAINED_RES2NET_PATH = ("E:/renkai/Joint_RK/Code/UML/models/"
                        #    "model_lib/pretrained_model_zoo/res2net50_v1b_26w_4s-3cf99910.pth")
PRETRAINED_RES2NET_PATH = None
SEG_CLASS = 2
CLS_CLASS = 2
# for optimizer
LEARNING_RATE = 0.00002
WEIGHT_DECAY = 1e-6

# ************************************************************************************ #
# ********************************** TRAINING SETTINGS ******************************* #
# ************************************************************************************ #
EPOCH = 200
TRAIN_NUM = 1270
# steps
WHOLE_STEPS = (TRAIN_NUM / BATCH_SIZE) * EPOCH
CHANGE_EPOCH = 30
POWER = 0.9
BASE_STEPS = (TRAIN_NUM / BATCH_SIZE) * CHANGE_EPOCH - 1
# loss
CLS_ANNEALING_EPOCH = 50
SEG_ANNEALING_EPOCH = 50
# loss weight
CLS_LOSS_WEIGHT = 0.5
MUT_LOSS_WEIGHT = 0.1
SEG_LOSS_WEIGHT = 0.4

# ************************************************************************************ #
# ********************************** VALID SETTINGS ********************************** #
# ************************************************************************************ #
VALID_EPOCH = 180

# ************************************************************************************ #
# ********************************** OTHER SETTINGS ********************************** #
# ************************************************************************************ #
COLOR = ["red", "green", "blue", "black", "yellow", "orange", "purple", "pink", "peru"]
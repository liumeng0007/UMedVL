name = "flair",
version = "0.1.0",

from .modeling.model import FLAIRModel


from torch.utils.data import Dataset
import torch
import torch.nn as nn
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import glob
from torchvision.transforms import transforms
import cv2



def get_boxes_prompts(image_name):
    """image_file_path = image_name
    查找包含指定图像名称的txt文件并读取其中的数字
    Args:
        path: 图像文件的路径
    Returns:
        list: 包含txt文件中的数字的列表，如果未找到相应文件则返回[0,0,0,0]
    """
    # 获取图像文件名
    image_name = image_name.split(".")[0]
    
    # txt文件所在文件夹路径
    txt_folder = "/home/ubuntu/桌面/UMLpaper_DATASET/Dataset_BUSI/Dataset_BUSI_for_train/DETR_pred_box"  # 替换为实际的txt文件夹路径
    
    try:
        # 遍历文件夹中的所有txt文件
        for txt_file in os.listdir(txt_folder):
            if txt_file.endswith('.txt') and image_name in txt_file:
                # 找到匹配的文件，读取内容
                with open(os.path.join(txt_folder, txt_file), 'r') as f:
                    content = f.read().strip()
                    # 将字符串转换为数字列表
                    numbers = [int(x.strip()) for x in content.split(',')]
                    return numbers
        
        # 如果未找到匹配的文件
        return [0, 0, 0, 0]
        
    except Exception as e:
        print(f"Error processing {image_name}: {str(e)}")
        return [0, 0, 0, 0]


def text_image_paired():
    df = pd.read_excel("/home/ubuntu/桌面/UMLpaper_DATASET/Dataset_BUSI/Dataset_BUSI_for_train/total_image_descriptions_en.xlsx", header=None)
    # df = pd.read_excel("/home/ubuntu/桌面/UMLpaper_DATASET/Dataset_BUSI/Dataset_BUSI_for_train/total_image_descriptions_en_10%.xlsx", header=None)
    # df = pd.read_excel("/home/ubuntu/桌面/UMLpaper_DATASET/Dataset_BUSI/Dataset_BUSI_for_train/total_image_descriptions_en_20%.xlsx", header=None)
    # df = pd.read_excel("/home/ubuntu/桌面/UMLpaper_DATASET/Dataset_BUSI/Dataset_BUSI_for_train/total_image_descriptions_en_30%.xlsx", header=None)
    # df = pd.read_excel("/home/ubuntu/桌面/UMLpaper_DATASET/Dataset_BUSI/Dataset_BUSI_for_train/total_image_descriptions_en_40%.xlsx", header=None)
    # df = pd.read_excel("/home/ubuntu/桌面/UMLpaper_DATASET/Dataset_BUSI/Dataset_BUSI_for_train/total_image_descriptions_en_50%.xlsx", header=None)
    
    image_name = df.iloc[:, 0]
    description = df.iloc[:, 1]
    paired_dict = dict(zip(image_name, description))
    return paired_dict

def get_labels_dict():
    df = pd.read_excel("/home/ubuntu/桌面/UMLpaper_DATASET/Dataset_BUSI/Dataset_BUSI_for_train/total_image_descriptions_en.xlsx", header=None)
    image_name = df.iloc[:, 0]
    label = df.iloc[:, 2]
    paired_dict = dict(zip(image_name, label))
    return paired_dict


class BUSI_Dataset(Dataset):
    def __init__(self, root_path, data_type: str = "Train"):
        """ The init function of BUSIDataset. Will load all image and mask file path.

        :param root_path: the root path of Refuge Dataset : "/home/ubuntu/桌面/UMLpaper_DATASET/refuge_glaucoma/Refuge_process_for_train"
        :param data_type: the data type, you have only 3 choices:
            - "Train" for train data
            - "Valid" for valid data
            - "Test" for test data
        """

        # ---- Step 1. Define the images and masks file path list ---- # 
        self.images_file_path_list = []
        self.masks_file_path_list = []
        self.texts_ls = []
        self.labels_ls = []
        total_texts = text_image_paired()
        total_labels = get_labels_dict()
        self.data_type = data_type

        # ---- Step 2. Get all images and masks path ---- #
        # construct the images and masks directory path
        images_directory_path = f"{root_path}/{data_type}/images"
        masks_directory_path = f"{root_path}/{data_type}/masks"
        # get the case id in directory
        for image_file_path in sorted(os.listdir(images_directory_path)):
            if image_file_path.endswith(".jpg") or image_file_path.endswith(".png"):
                self.images_file_path_list.append(f"{images_directory_path}/{image_file_path}")
                if image_file_path in total_texts.keys():
                    self.texts_ls.append(total_texts[image_file_path])
                else:
                    print(f"No description found for this image{image_file_path}.")
                if image_file_path in total_labels.keys():
                    self.labels_ls.append(int(total_labels[image_file_path]))
                else:
                    print(f"No label found for this image{image_file_path}.")

        for mask_file_path in sorted(os.listdir(masks_directory_path)):
            if mask_file_path.endswith(".bmp") or mask_file_path.endswith(".png"):
                self.masks_file_path_list.append(f"{masks_directory_path}/{mask_file_path}")

        # ---- Step 3. Check Data Len ---- #
        assert len(self.images_file_path_list) == len(self.masks_file_path_list), "Image Mask num not total equal !!!"
        
        self.transform = transforms.Compose([
            transforms.ToPILImage(),
            # transforms.RandomHorizontalFlip(p=0.5),
            # transforms.RandomVerticalFlip(p=0.5),
            # transforms.RandomRotation(15),
            transforms.ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1, hue=0.1),
            transforms.ToTensor()
        ])

    def __len__(self):
        
        """ Get the length of dataset. """

        return len(self.images_file_path_list)

    def __getitem__(self, idx: int):
        """ Get the item.

        :param idx: the item idx

        return: a dict with the format:
            {
                "image": the image array, shape=(3, 256, 256) --> (3, 224, 224)
                "cls_label": the label for classification, shape=(1,),
                "seg_gt": the ground truth for segmentation, shape=(1, 256, 256),
                    only have 0, 1 and 2, 0-gd, 1-cup and 2-disc
                "item_name": a str,
            }
        """

        # ---- Check image and mask right ---- #
        # "/home/ubuntu/桌面/UMLpaper_DATASET/refuge_glaucoma/Refuge_process_for_train/Train/images/g0001_1_img.jpg"; "g0001_1_msk.bmp"
        image_name = self.images_file_path_list[idx].split("/")[-1]
        image_id = image_name.split(".")[0]  # 注意这里image_id 的取出方式
        mask_name = self.masks_file_path_list[idx].split("/")[-1]
        mask_id = mask_name.split(".")[0].split("_")[0]  # 注意这里mask_id 的取出方式
        assert image_id == mask_id, "Image Mask not Right !!!"

        # ---- Read the image, label and mask ---- #
        # - image
        image = plt.imread(self.images_file_path_list[idx]).copy()  # shape=(h, w, 3)
        # image1 = cv2.imread(self.images_file_path_list[idx])  # shape=(h, w, 3)
        image = image.transpose(2, 0, 1)  # scale to [0, 1], and transpose to (3, h, w)
        image = torch.tensor(image, dtype=torch.float32)
        image = nn.functional.interpolate(image.unsqueeze(0), size=(256, 256), mode='bilinear',
                                          align_corners=False).squeeze(0)
        assert (0.0 <= image).all() and (image <= 1.0).all(), "image value ERROR !!!"   
        # if self.transform:
        #     image = self.transform(image)

        # image = plt.imread(self.images_file_path_list[idx])  # shape=(h, w, 3)
        # image = cv2.resize(image, (256, 256))  # Resize to (256, 256)
        # if self.data_type == "Train":
        #     image = self.transform(image)
        #     # image = np.array(image).transpose(2, 0, 1)  # scale to [0, 1], and transpose to (3, h, w)
        # assert (0.0 <= image).all() and (image <= 1.0).all(), "image value ERROR !!!"
        # cv2.imshow("image",image)
        # cv2.waitKey()
        # cv2.destroyAllWindows()
        # - label for classification task
        # cls_label = int(image_name.split("_")[-2])  # shape=(1,)
        cls_label = self.labels_ls[idx]
        # - gt for segmentation task, and make it to 0-gd, 1-cup, 2-disc
        seg_gt = plt.imread(self.masks_file_path_list[idx]).copy()  # shape=(h, w)
        if len(seg_gt.shape) == 3:  # If RGB, convert to grayscale
            seg_gt = cv2.cvtColor(seg_gt, cv2.COLOR_RGB2GRAY)
        # seg_gt[seg_gt < 128] = 0
        # seg_gt[seg_gt > 128] = 1
        seg_gt = seg_gt.reshape(1, seg_gt.shape[0], seg_gt.shape[1])
        seg_gt = torch.tensor(seg_gt, dtype=torch.float32)
        seg_gt = nn.functional.interpolate(seg_gt.unsqueeze(0), size=(256, 256), mode='nearest').squeeze(0)
        # plt.imshow(seg_gt.squeeze(0).numpy(), cmap="gray")
        # plt.show()
        # cv2.imshow("seg_gt",seg_gt.squeeze(0).numpy())
        # cv2.waitKey()
        # cv2.destroyAllWindows()
        # seg_gt : torch.Size([1, 1024, 1024])

        # - the item name, just be the image name
        item_name = image_name
        # - texts for training
        texts = self.texts_ls[idx]
        # - get the boxes
        # boxes = get_boxes_prompts(self.masks_file_path_list[idx])
        boxes = get_boxes_prompts(image_name)
        box_ary = (np.array(boxes) * 0.5).astype(int)

        # ---- Construct the item ---- #
        item = {
            "image": image, # torch.Size([3, 1024, 1024])
            "texts": texts,
            "cls_label": cls_label,
            "mask_inputs": seg_gt,  # torch.Size([1, 1024, 1024])
            "item_name": item_name,
            "boxes": box_ary
        }

        return item


if __name__ == "__main__":
    # Define the root path and data type
    root_path = "/home/ubuntu/桌面/UMLpaper_DATASET/Dataset_BUSI/Dataset_BUSI_for_train"
    data_type = "Test"

    # Create an instance of the dataset
    dataset = BUSI_Dataset(root_path, data_type)

    # Iterate through the dataset and check images and mask_inputs
    for idx in range(len(dataset)):
        item = dataset[idx]
        image = item["image"]
        mask_inputs = item["mask_inputs"]

        # Print shapes and check value ranges
        print(f"Index: {idx}")
        print(f"Image shape: {image.shape}, Min: {image.min()}, Max: {image.max()}")
        print(f"Mask shape: {mask_inputs.shape}, Min: {mask_inputs.min()}, Max: {mask_inputs.max()}")

        # Optionally, visualize the image and mask
        # if idx < 5:  # Visualize first 5 samples
        #     plt.figure(figsize=(10, 5))
        #     plt.subplot(1, 2, 1)
        #     plt.title("Image")
        #     plt.imshow(image.permute(1, 2, 0).numpy())
        #     plt.subplot(1, 2, 2)
        #     plt.title("Mask")
        #     plt.imshow(mask_inputs.squeeze(0).numpy(), cmap="gray")
        #     plt.show()
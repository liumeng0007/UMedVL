# -*- coding: utf-8 -*-
# @Time    : 2023/3/20 16:42
# @Author  : Karry Ren

""" The torch.Dataset of I-SPY1 dataset.

After the preprocessing raw I-SPY1 dataset (download from web) by
    run `python ispy_preprocess.py` you will get the following I-SPY1 dataset directory:
    ISPY_DATASET_PATH/
        ├── Train
            ├── images
                ├── ispy_xxxx1 (KEEP_SLICE_NUM images)
                    ├── ispy_xxxx1_pcr_s1_img.jpg
                    ├── ispy_xxxx1_pcr_s2_img.jpg
                    ├── ...
                    └── ispy_xxxx1_pcr_sn_img.jpg
                ├── ispy_xxxx2
                ├── ...
                └── ispy_xxxxn
            └── masks
                ├── ispy_xxxx1 (KEEP_SLICE_NUM masks)
                    ├── ispy_xxxx1_pcr_s1_msk.jpg
                    ├── ispy_xxxx1_pcr_s2_msk.jpg
                    ├── ...
                    └── ispy_xxxx1_pcr_sn_msk.jpg
                ├── ispy_xxxx2
                ├── ...
                └── ispy_xxxxn
        ├── Valid
            ├── images
            └── masks
        └── Test
            ├── images
            └── masks

In this dataset:
    - during `__init__()`, we will LOAD all images and masks file path.
    - during `__getitem__()`, we will READ 1 image and mask and label to memory.

"""

import torch.utils.data
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import glob
from torchvision.transforms import transforms
import cv2


# def get_boxes_prompts(path):
#     mask = cv2.imread(path)  # Replace 'input_image.jpg' with the path to your image
#     mask = cv2.resize(mask, (256, 256))  # Resize to (256, 256)
#     tumor_mask = (mask[:, :, 0] > 128).astype(np.uint8)  # Extract tumor region from the red channel
#     contours, _ = cv2.findContours(tumor_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

#     # Find the bounding rectangle for the largest contour
#     if contours:
#         largest_contour = max(contours, key=cv2.contourArea)
#         x, y, w, h = cv2.boundingRect(largest_contour)
#         # image_with_box = mask.copy()
#         # cv2.rectangle(image_with_box, (x, y), (x + w, y + h), (0, 0, 255), 2)  # Red rectangle for the tumor region

#         # # Display the image with the bounding box
#         # plt.imshow(cv2.cvtColor(image_with_box, cv2.COLOR_BGR2RGB))
#         # plt.title("Image with Bounding Box")
#         # plt.axis("off")
#         # plt.show()
#         return [x, y, x + w, y + h]  # Coordinates of the rectangle
#     else:
#         return [0, 0, 0, 0]  # No tumor found
#     # return [0, 0, 0, 0]  # No tumor found

# 重新get_boxes_prompts, 从DETR中获取box坐标
def get_boxes_prompts(image_name):
    """
    查找包含指定图像名称的txt文件并读取其中的数字
    Args:
        path: 图像文件的路径
    Returns:
        list: 包含txt文件中的数字的列表，如果未找到相应文件则返回[0,0,0,0]
    """
    # 获取图像文件名
    image_name = image_name.split(".")[0]
    
    # txt文件所在文件夹路径
    txt_folder = "/home/ubuntu/桌面/UMLpaper_DATASET/I-SYP1/I-SYP1_process_for_train/DETR_pred_box"  # 替换为实际的txt文件夹路径
    
    try:
        # 遍历文件夹中的所有txt文件
        for txt_file in os.listdir(txt_folder):
            if txt_file.endswith('.txt') and image_name in txt_file:
                # 找到匹配的文件，读取内容
                with open(os.path.join(txt_folder, txt_file), 'r') as f:
                    content = f.read().strip()
                    # 将字符串转换为数字列表
                    numbers = [int(x.strip()) for x in content.split(',')]
                    return numbers
        
        # 如果未找到匹配的文件
        return [0, 0, 0, 0]
        
    except Exception as e:
        print(f"Error processing {image_name}: {str(e)}")
        return [0, 0, 0, 0]



def text_image_paired():
    df = pd.read_excel("/home/ubuntu/桌面/UMLpaper_DATASET/I-SYP1/I-SYP1_process_for_train/total_image_descriptions_en.xlsx", header=None)
    # df = pd.read_excel("/home/ubuntu/桌面/UMLpaper_DATASET/I-SYP1/I-SYP1_process_for_train/total_image_descriptions_en_10%.xlsx", header=None)
    # df = pd.read_excel("/home/ubuntu/桌面/UMLpaper_DATASET/I-SYP1/I-SYP1_process_for_train/total_image_descriptions_en_20%.xlsx", header=None)
    # df = pd.read_excel("/home/ubuntu/桌面/UMLpaper_DATASET/I-SYP1/I-SYP1_process_for_train/total_image_descriptions_en_30%.xlsx", header=None)
    # df = pd.read_excel("/home/ubuntu/桌面/UMLpaper_DATASET/I-SYP1/I-SYP1_process_for_train/total_image_descriptions_en_40%.xlsx", header=None)
    # df = pd.read_excel("/home/ubuntu/桌面/UMLpaper_DATASET/I-SYP1/I-SYP1_process_for_train/total_image_descriptions_en_50%.xlsx", header=None)
    image_name = df.iloc[:, 0]
    description = df.iloc[:, 1]
    paired_dict = dict(zip(image_name, description))
    return paired_dict


class JointIspyDataset(torch.utils.data.Dataset):
    """ The Joint I-SPY1 Dataset. """

    def __init__(self, root_path: str, data_type: str = "Train"):
        """ The init function of JointIspyDataset. Will load all image and mask file path.

        :param root_path: the root path of I-SPY1 Dataset
        :param data_type: the data type, you have only 3 choices:
            - "Train" for train data
            - "Valid" for valid data
            - "Test" for test data

        """

        # ---- Step 1. Define the images and masks file path list ---- #
        self.images_file_path_list = []
        self.masks_file_path_list = []
        self.texts_ls = []
        self.data_type = data_type
        total_texts = text_image_paired()

        # ---- Step 2. Get all cases ---- #
        # construct the images and masks directory path
        images_directory_path = f"{root_path}/{data_type}/images"
        masks_directory_path = f"{root_path}/{data_type}/masks"

        # get the case id in directory
        images_case_id_list = sorted(os.listdir(images_directory_path))
        masks_case_id_list = sorted(os.listdir(masks_directory_path))
        assert images_case_id_list == masks_case_id_list, "images cases are not == masks cases !!!"
        case_id_list = images_case_id_list  # set the images_cases_list to cases_list

        # ---- Step 3. Read all images and masks file path ---- #
        for case_id in case_id_list:
            # get the cased images and masks directory
            images_case_id_directory_path = f"{images_directory_path}/{case_id}"
            masks_case_id_directory_path = f"{masks_directory_path}/{case_id}"
            # get all images and masks file path
            images_case_id_path_list = sorted(os.listdir(images_case_id_directory_path))
            masks_case_id_path_list = sorted(os.listdir(masks_case_id_directory_path))
            assert len(images_case_id_path_list) == len(masks_case_id_path_list), "Image Mask num not equal !!!"
            # append all path to list
            for images_case_id_path in images_case_id_path_list:
                self.images_file_path_list.append(f"{images_case_id_directory_path}/{images_case_id_path}")
                if images_case_id_path in total_texts.keys():
                    self.texts_ls.append(total_texts[images_case_id_path])
            for masks_case_id_path in masks_case_id_path_list:
                self.masks_file_path_list.append(f"{masks_case_id_directory_path}/{masks_case_id_path}") # 每一张二维图像
            

        # ---- Step 4. Check Data Len ---- #
        assert len(self.images_file_path_list) == len(self.masks_file_path_list), "Image Mask num not total equal !!!"
        self.transform = transforms.Compose([
            transforms.ToPILImage(),
            # transforms.RandomHorizontalFlip(p=0.5),
            # transforms.RandomVerticalFlip(p=0.5),
            # transforms.RandomRotation(15),
            transforms.ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1, hue=0.1),
            transforms.ToTensor()
        ])

    def __len__(self):
        """ Get the length of dataset. """

        return len(self.images_file_path_list)

    def __getitem__(self, idx: int):
        """ Get the item.

        :param idx: the item idx

        return: a dict with the format: 
            {
                "image": the image array, shape=(3, 128, 128)  # 
                "cls_label": the label for classification, shape=(1,)
                "seg_gt": the ground truth for segmentation, shape=(1, 128, 128)
                    only have 0 and 1, 0-gd and 1-tumor
                "item_name": a str
            }
        """

        # ---- Check image and mask right ---- #
        image_name = self.images_file_path_list[idx].split("/")[-1]
        image_case_id = image_name.split("_")[1]
        image_slice_num = image_name.split("_")[3]
        mask_name = self.masks_file_path_list[idx].split("/")[-1]
        mask_case_id = mask_name.split("_")[1]
        mask_slice_num = mask_name.split("_")[3]
        assert image_case_id == mask_case_id and image_slice_num == mask_slice_num, "Image Mask not Right !!!"

        # ---- Read the image, label and mask ---- #
        # - image
        image = plt.imread(self.images_file_path_list[idx])  # shape=(h, w, 3)
        image = cv2.resize(image, (256, 256))  # Resize to (256, 256)
        if self.data_type == "Train":
            image = self.transform(image)
            # image = np.array(image).transpose(2, 0, 1)  # scale to [0, 1], and transpose to (3, h, w)
        else:
            image = np.array((image / 255)).transpose(2, 0, 1)  # scale to [0, 1], and transpose to (3, h, w)
        assert (0.0 <= image).all() and (image <= 1.0).all(), "image value ERROR !!!"
        # - label for classification task
        cls_label = np.array([int(image_name.split("_")[2])])  # shape=(1,)
        # - gt for segmentation task, and make it 0-gd, 1-tumor
        seg_gt = plt.imread(self.masks_file_path_list[idx])[:, :, 0]  # shape=(h, w)
        seg_gt = cv2.resize(seg_gt, (256, 256))
        seg_gt = (seg_gt >= 50).astype(np.int8)  # avoid not 0 or 1
        seg_gt = seg_gt.reshape(1, seg_gt.shape[0], seg_gt.shape[1])
        seg_gt = torch.tensor(seg_gt, dtype=torch.float32)
        # - the item name, just be the image name
        item_name = image_name
        # text
        texts = self.texts_ls[idx]
        # box
        # boxes = get_boxes_prompts(self.masks_file_path_list[idx])
        boxes = get_boxes_prompts(image_name)
        box_ary = np.array(boxes)

         
        # ---- Construct the item ---- #
        item = {
            "image": image,
            "texts": texts,
            "cls_label": cls_label,
            "mask_inputs": seg_gt,
            "item_name": item_name,
            "boxes": box_ary
        }

        return item
    



if __name__ == "__main__":  # a demo using JointIspyDataset
    ISPY_DATASET_PATH = "/home/ubuntu/桌面/UMLpaper_DATASET/I-SYP1/I-SYP1_process_for_train"

    ispy_dataset = JointIspyDataset(root_path=ISPY_DATASET_PATH, data_type="Train")

    for idx in range(len(ispy_dataset)):
        item = ispy_dataset[idx]
        image = item["image"]
        mask_inputs = item["mask_inputs"]

        # Print shapes and check value ranges
        print(f"Index: {idx}")
        print(f"Image shape: {image.shape}, Min: {image.min()}, Max: {image.max()}")
        print(f"Mask shape: {mask_inputs.shape}, Min: {mask_inputs.min()}, Max: {mask_inputs.max()}")


    # show the image
    # print(liver_ds[1]["item_name"])
    # print(liver_ds[1]["image"].shape)
    # print(liver_ds[1]["seg_gt"].shape)
    # print(liver_ds[1]["cls_label"])
    # plt.subplot(1, 2, 1)
    # plt.imshow(liver_ds[1]["image"].permute(1, 2, 0))
    # plt.subplot(1, 2, 2)
    # plt.imshow(liver_ds[1]["seg_gt"].permute(1,2,0))
    # plt.show()

    # for i in range(len(ispy_dataset)):
    #     print(ispy_dataset[i]["image"].max(), ispy_dataset[i]["image"].min())
    #     print(ispy_dataset[i]["seg_gt"].sum())
    # get_8_classes(root_path)
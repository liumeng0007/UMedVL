"""
fine tune the vision model of the FLAIR model
"""
from flair.modeling.model import VisionModel, ProjectionLayer, FLAIRModel
import flair.config_refuge as config

import torch
import torch.nn as nn
from torchvision import transforms
import os
from matplotlib import pyplot as plt
from tqdm import tqdm
from typing import Optional
import numpy as np
from sklearn.metrics import f1_score
from torch.utils.data import Dataset, DataLoader
import loralib as lora



def adjust_lr(optimizer: torch.optim.Optimizer, base_lr: float, step: int, epoch: int, whole_steps: int,
              base_steps: int, power: float, change_epoch: Optional[int] = 30) -> None:
    """ Adjust the learning rate.

    :param optimizer: the optimizer
    :param base_lr: the initial learning rate
    :param step: the current step
    :param epoch: the current epoch
    :param whole_steps: the whole steps
    :param base_steps: the base train steps
    :param power: lr down power
    :param change_epoch: the change epoch

    Returns:
        the new lr for one step

    """

    # ---- Change the lr based on the steps ---- #
    if change_epoch is not None:  # have the change epoch
        if epoch >= change_epoch:  # after the change epoch, start changing (be smaller)
            new_lr = base_lr * ((1 - float(step - base_steps) / (whole_steps - base_steps)) ** power)
        else:  # before the change epoch, keep lr
            new_lr = base_lr
    else:  # not have the change epoch, keep changing
        new_lr = base_lr * ((1 - float(step) / whole_steps) ** power)

    # ---- Bound lr it to 1e-5 ---- #
    if abs(new_lr) <= 1e-5:
        new_lr = 1e-5

    # ---- Set the lr to optimizer ---- #
    optimizer.param_groups[0]["lr"] = new_lr

class Refuge_Dataset(Dataset):
    def __init__(self, root_path, data_type: str = "Train"):
        """ The init function of RefugeDataset. Will load all image and mask file path.

        :param root_path: the root path of Refuge Dataset : "/home/ubuntu/桌面/UMLpaper_DATASET/refuge_glaucoma/Refuge_process_for_train"
        :param data_type: the data type, you have only 3 choices:
            - "Train" for train data
            - "Valid" for valid data
            - "Test" for test data
        """

        # ---- Step 1. Define the images and masks file path list ---- #
        self.images_file_path_list = []
        self.masks_file_path_list = []
        self.texts_ls = []
        # self.texts_ls = [("A fundus image of glaucoma.", "A fundus image of non-glaucoma.") for _ in range(400)]

        # ---- Step 2. Get all images and masks path ---- #
        # construct the images and masks directory path
        images_directory_path = f"{root_path}/{data_type}/images"
        masks_directory_path = f"{root_path}/{data_type}/masks"
        # get the case id in directory
        for image_file_path in sorted(os.listdir(images_directory_path)):
            self.images_file_path_list.append(f"{images_directory_path}/{image_file_path}")
        for mask_file_path in sorted(os.listdir(masks_directory_path)):
            self.masks_file_path_list.append(f"{masks_directory_path}/{mask_file_path}")

        # ---- Step 3. Check Data Len ---- #
        assert len(self.images_file_path_list) == len(self.masks_file_path_list), "Image Mask num not total equal !!!"
        # for image in self.images_file_path_list:
        #     input_attention = cls1_inputs_id, cls1_attention_mask, cls2_inputs_id, cls2_attention_mask
        #     self.texts_ls.append(input_attention)  # cls1_inputs_id, cls1_attention_mask, cls2_inputs_id, cls2_attention_mask

        self.transform = transforms.Compose([
            transforms.ToPILImage(),
            # transforms.RandomHorizontalFlip(p=0.5),
            # transforms.RandomVerticalFlip(p=0.5),
            transforms.RandomRotation(15),
            transforms.ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1, hue=0.1),
            transforms.ToTensor()
        ])

    def __len__(self):
        
        """ Get the length of dataset. """

        return len(self.images_file_path_list)

    def __getitem__(self, idx: int):
        """ Get the item.

        :param idx: the item idx

        return: a dict with the format:
            {
                "image": the image array, shape=(3, 128, 128) --> (3, 224, 224)
                "cls_label": the label for classification, shape=(1,),
                "seg_gt": the ground truth for segmentation, shape=(1, 128, 128),
                    only have 0, 1 and 2, 0-gd, 1-cup and 2-disc
                "item_name": a str,
            }
        """

        # ---- Check image and mask right ---- #
        # "/home/ubuntu/桌面/UMLpaper_DATASET/refuge_glaucoma/Refuge_process_for_train/Train/images/g0001_1_img.jpg"; "g0001_1_msk.bmp"
        image_name = self.images_file_path_list[idx].split("/")[-1]
        image_id = image_name.split("_")[0]
        mask_name = self.masks_file_path_list[idx].split("/")[-1]
        mask_id = mask_name.split("_")[0]
        assert image_id == mask_id, "Image Mask not Right !!!"

        # ---- Read the image, label and mask ---- #
        # - image
        image = plt.imread(self.images_file_path_list[idx]).copy()  # shape=(h, w, 3)
        image = (image / 255).transpose(2, 0, 1)  # scale to [0, 1], and transpose to (3, h, w)
        image = torch.tensor(image, dtype=torch.float32)
        image = nn.functional.interpolate(image.unsqueeze(0), size=(224, 224), mode='bilinear',
                                          align_corners=False).squeeze(0)
        assert (0.0 <= image).all() and (image <= 1.0).all(), "image value ERROR !!!"
        if self.transform:
            image = self.transform(image)

        # - label for classification task
        cls_label = int(image_name.split("_")[-2])  # shape=(1,)
        # - gt for segmentation task, and make it to 0-gd, 1-cup, 2-disc
        # seg_gt = plt.imread(self.masks_file_path_list[idx])[:, :, 0].copy()  # shape=(h, w)
        # seg_gt[seg_gt < 10] = 2
        # seg_gt[(seg_gt >= 10) & (seg_gt <= 245)] = 1
        # seg_gt[seg_gt > 245] = 0
        # seg_gt = seg_gt.reshape(1, seg_gt.shape[0], seg_gt.shape[1])
        # seg_gt = torch.tensor(seg_gt, dtype=torch.float32)
        # seg_gt = nn.functional.interpolate(seg_gt.unsqueeze(0), size=(224, 224), mode='nearest').squeeze(0)
        # - the item name, just be the image name
        item_name = image_name
        # - texts for training
        # texts = self.texts_ls[idx]

        # ---- Construct the item ---- #
        item = {
            "image": image,
            # "texts": texts,
            "cls_label": cls_label,
            # "seg_gt": seg_gt,
            "item_name": item_name
        }

        return item

def fit_net(epoch, model, train_dataloader, valid_loader, loss_fn, optimizer):
    """
    classification: 计算MAE/MSE/RMSE/MPE/R_2
    :param model: 初始化的模型
    :param train_dataloader: 训练集dataloader
    :param test_dataloader:  测试集dataloader
    :param loss_fn: 损失函数
    :param optim: 优化器
    :param lr_scheduler_epoch: 学习率的衰减,stepLR()
    :return: train_loss, train_acc, test_loss, test_acc。这是四个标量值
    """

    total_correct = 0
    epoch_loss = 0
    total_preds = []
    total_labels = []
    model.cuda()

    model.train()  # 模型训练模式
    for i, batch_data in enumerate(train_dataloader):
        step = (config.TRAIN_NUM / config.BATCH_SIZE) * epoch + i
        pixel_values = batch_data["image"].to(dtype=torch.float32).cuda()  # images, shape=(bs, 3, h, w)
        cls_labels = batch_data["cls_label"].to(dtype=torch.int64).cuda() 
        preds = model(pixel_values)
        loss = loss_fn(preds, cls_labels)
        optimizer.zero_grad()
        adjust_lr(optimizer=optimizer, base_lr=config.LEARNING_RATE, step=step, epoch=epoch,
                    whole_steps=config.WHOLE_STEPS, base_steps=config.BASE_STEPS,
                    power=config.POWER, change_epoch=config.CHANGE_EPOCH)  # adjust the lr of optimizer
        loss.backward()
        optimizer.step()
        correct = (preds.argmax(dim=1) == cls_labels).float().sum()  # Count correct predictions
        total_correct += correct.item()  # Accumulate correct predictions
        total_preds.extend(preds.argmax(dim=1).cpu().numpy())
        total_labels.extend(cls_labels.cpu().numpy())
        epoch_loss += loss.item()

    epoch_loss /= len(train_dataloader)  # Average loss for the epoch
    # Calculate accuracy and F1 score for the epoch
    accuracy = total_correct / len(train_dataloader.dataset)
    total_preds = np.array(total_preds)
    total_labels = np.array(total_labels)
    f1 = f1_score(total_labels, total_preds, average='weighted')
    current_lr = optimizer.param_groups[0]['lr']
    # print(f"Training: Epoch [{epoch}/{config.EPOCH}], Loss:{epoch_loss:.4f}, Accuracy: {accuracy:.4f}, F1 Score: {f1:.4f}, learning rate:{current_lr}")
    
    # Validate the model
    model.eval()
    total_val_preds = []
    total_val_labels = []
    val_loss = 0
    val_correct = 0
    with torch.no_grad():
        for i, batch_data in enumerate(valid_loader):
            val_pixel_values = batch_data["image"].to(dtype=torch.float32).cuda()
            val_cls_labels = batch_data["cls_label"].to(dtype=torch.int64).cuda()

            val_preds = model(val_pixel_values)
            val_correct += (val_preds.argmax(dim=1) == val_cls_labels).float().sum()  # Count correct predictions
            val_loss += loss_fn(val_preds, val_cls_labels).item()
            total_val_preds.extend(val_preds.argmax(dim=1).cpu().numpy())
            total_val_labels.extend(val_cls_labels.cpu().numpy())

        # Calculate accuracy and F1 score for the validation set
        val_loss /= len(valid_loader)  # Average loss for the validation set
        val_accuracy = val_correct / len(valid_loader.dataset)  # Accuracy for the validation set
        total_val_preds = np.array(total_val_preds)
        total_val_labels = np.array(total_val_labels)
        # Calculate accuracy and F1 score for the validation set
        # val_accuracy = val_correct / len(valid_loader.dataset)
        val_f1 = f1_score(total_val_labels, total_val_preds, average='weighted')
        # print(f"Validation: Epoch [{epoch}/{config.EPOCH}], Loss:{val_loss:.4f}, Accuracy: {val_accuracy:.4f}, Validation F1 Score: {val_f1:.4f}")

    return epoch, epoch_loss, accuracy, f1, val_loss, val_accuracy, val_f1, current_lr


def train(model, train_dataloader, valid_loader, loss_fn, optimizer):
    for epoch in range(config.EPOCH):
        epoch, train_epoch_loss, train_accuracy, train_f1, val_loss, val_accuracy, val_f1, current_lr = fit_net(epoch,
                                                                                                    model, 
                                                                                                    train_dataloader, 
                                                                                                    valid_loader, 
                                                                                                    loss_fn, 
                                                                                                    optimizer)
        
        print(f"epoch:{epoch}, current_lr:{current_lr}, train: trainloss:{train_epoch_loss:.4f}, trainacc:{train_accuracy:.4f}, train_f1:{train_f1:.4f}, validation: valloss{val_loss:.4f}, val_acc:{val_accuracy:.4f}, val_f1:{val_f1:.4f}")


class Totalmodel(torch.nn.Module):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        weight_path = "/home/ubuntu/PycharmProjects/FLAIR-1/flair/modeling/flair_pretrained_weights/flair_resnet.pth"
        model = FLAIRModel(weights_path=weight_path, from_checkpoint=True)
        self.vision_model = model.vision_model
        for name, param in self.vision_model.named_parameters():
            param.requires_grad = False
        self.linear = torch.nn.Linear(512, 2)

    def forward(self, x):
        x = self.vision_model(x)
        x = self.linear(x)
        return x
    
class LoRAResNet(nn.Module):
    def __init__(self, lora_rank=4):
        super(LoRAResNet, self).__init__()
        self.resnet = Totalmodel()
        self.lora_layers = nn.ModuleList()
        
        # Collect all linear layers to apply LoRA
        linear_layers = []
        for name, module in self.resnet.named_modules():
            if isinstance(module, nn.Linear):
                linear_layers.append((name, module))
        
        # Apply LoRA to collected linear layers
        for name, module in linear_layers:
            lora_layer = lora.Linear(module.in_features, module.out_features, r=lora_rank)
            self.lora_layers.append(lora_layer)
            setattr(self.resnet, name, lora_layer)

    def forward(self, x):
        return self.resnet(x)



if __name__ == "__main__":

    vision_model = LoRAResNet(lora_rank=4)

    train_loader = DataLoader(  
        Refuge_Dataset(root_path=config.REFUGE_ROOT_PATH, data_type="Train"), batch_size=config.BATCH_SIZE, shuffle=True)  # train dataloader
    valid_loader = DataLoader(
        Refuge_Dataset(root_path=config.REFUGE_ROOT_PATH, data_type="Valid"), batch_size=config.BATCH_SIZE, shuffle=False)
  
    optimizer = torch.optim.Adam(vision_model.parameters(), lr=0.0001)
    loss_fn = nn.CrossEntropyLoss(weight=torch.Tensor([1.0, 9.0]).cuda())
    # loss_fn = nn.CrossEntropyLoss()

    train(vision_model, train_loader, valid_loader, loss_fn, optimizer)








































This folder contains some examples of fundus images to introduce the use of FLAIR model.
* `normal_sample.png`: a normal sample, healthy, from a private dataset.
* `sample_macular_hole.png`: a sample from an eye with a macular hole. Note that FLAIR has not seen this category during training.
Obtained from the creative commons licensed source: [Link](https://upload.wikimedia.org/wikipedia/commons/f/f2/Aspect_d%27un_trou_maculaire_en_fond_d%27oeil.png).
* `normal_sample.png`: a sample from an eye diagnoses as severe-non-proliferative diabetic retinopathy. 
Obtained from the creative commons licensed source: [Link](https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.flickr.com%2Fphotos%2Fcommunityeyehealth%2F26134010075&psig=AOvVaw0vuzjdTDlOEIE7ahhc8Zyf&ust=1692296305292000&source=images&cd=vfe&opi=89978449&ved=0CBAQjRxqFwoTCPCM9ZLl4YADFQAAAAAdAAAAABAJ).
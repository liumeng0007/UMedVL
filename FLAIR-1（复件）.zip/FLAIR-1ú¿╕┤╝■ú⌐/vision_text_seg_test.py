"""
test the vision_text_seg model
coupled and discoupled image-text
"""

from vision_text_seg_finetune import Refuge_Dataset, CLS_SEG_Model, mean_iou
import flair.config_refuge as config
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import pandas as pd
import glob
from tqdm import tqdm
from sklearn.metrics import accuracy_score, f1_score
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import os
import cv2
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

def dice_score(prediction, ground_truth):
    intersection = np.sum(prediction * ground_truth)
    dice = (2.0 * intersection) / (np.sum(prediction) + np.sum(ground_truth))
    return dice


from scipy.spatial.distance import cdist


def compute_surface_distances(prediction, ground_truth):
    # 提取表面点
    prediction_surface = np.argwhere(prediction > 0)
    ground_truth_surface = np.argwhere(ground_truth > 0)

    if prediction_surface.size == 0 or ground_truth_surface.size == 0:
        return float('inf')

    # 计算单向表面距离
    dist_pred_to_gt = cdist(prediction_surface, ground_truth_surface).min(axis=1)
    dist_gt_to_pred = cdist(ground_truth_surface, prediction_surface).min(axis=1)

    # 计算对称表面距离
    assd = (np.mean(dist_pred_to_gt) + np.mean(dist_gt_to_pred)) / 2.0
    return assd


def infer(x: torch.Tensor):
    """ Infer function of dirichlet distribution.

    :param x: the input, shape=(bs, cls_class)

    returns:
        - evidence: the Positive evidence, shape=(bs, cls_class, h, w)

    """

    # ---- Non negative computation --- #
    evidence = F.softplus(x)
    return evidence


def test(model, test_loader):
    model.eval()
    total_val_preds = []
    total_val_labels = []
    item_name_ls = []
    cls_uncertainty_ls = []
    total_val_probs = []
    val_mean_iou = 0

    # 这是为了测试用的
    with torch.no_grad():
        for i, batch_data in enumerate(test_loader):
            val_pixel_values = batch_data["image"].to(dtype=torch.float32).cuda()
            val_cls_labels = batch_data["cls_label"].to(dtype=torch.float).cuda()
            val_text = batch_data["texts"]
            val_masks = batch_data["mask_inputs"].cuda()  # c
            val_names = batch_data["item_name"]

            _, _, val_preds_logits, val_masks_hq = model(val_pixel_values, val_text, batch_data)
            # Visualize the predicted mask
            # Convert logits to probabilities using softmax
            val_masks_probs = F.softmax(val_masks_hq, dim=1)  # Shape: (bs, 3, 256, 256)

            # Get the predicted class for each pixel
            val_masks_pred = torch.argmax(val_masks_probs, dim=1)  # Shape: (bs, 256, 256)

            # Visualize the ground truth mask
            # Save the first ground truth mask in the batch
            output_dir = "/home/ubuntu/PycharmProjects/FLAIR-1/output_masks"
            os.makedirs(output_dir, exist_ok=True)
            output_path = os.path.join(output_dir, f"{val_names[0]}_ground_truth_1.png")
            plt.imsave(output_path, val_masks[1, 0].cpu().numpy(), cmap='gray')

            # Save the first predicted mask in the batch
            output_path_pred = os.path.join(output_dir, f"{val_names[0]}_predicted_mask_1.png")
            plt.imsave(output_path_pred, val_masks_pred[1].cpu().numpy(), cmap='gray')
            # plt.figure(figsize=(8, 8))
            # # plt.imshow(val_pixel_values[0].cpu().numpy().transpose(1, 2, 0))
            # plt.imshow(val_masks[0, 0].cpu().numpy(), cmap='gray')
            # plt.title("Ground Truth Mask")
            # plt.axis('off')
            # plt.show()

            # Visualize the ground truth mask
            # plt.figure(figsize=(8, 8))
            # plt.imshow(val_masks[0, 0].cpu().numpy(), cmap='gray')
            # plt.title("Ground Truth Mask")
            # plt.axis('off')
            # plt.show()

            # Visualize the first predicted mask in the batch
            # plt.figure(figsize=(8, 8))
            # plt.imshow(val_masks_pred[0].cpu().numpy(), cmap='gray')
            # plt.title(f"Predicted Mask")
            # plt.axis('off')
            # plt.show()

            
            # Calculate dice and ASSD for each class (1: optic disc, 2: optic cup)
            dice_scores = {"optic_disc": [], "optic_cup": []}
            assd_scores = {"optic_disc": [], "optic_cup": []}

            # for class_id, class_name in zip([1, 2], ["optic_disc", "optic_cup"]):
            #     for idx in range(val_masks_pred.shape[0]):  # 遍历当前批次中的每个样本
            #         pred_class = (val_masks_pred[idx] == class_id).cpu().numpy()
            #         gt_class = (val_masks[idx].squeeze(0) == class_id).cpu().numpy()

            #         # Calculate Dice score
            #         dice = dice_score(pred_class, gt_class)
            #         dice_scores[class_name].append(dice)

            #         # Calculate ASSD
            #         assd = compute_surface_distances(pred_class, gt_class)
            #         assd_scores[class_name].append(assd)

            # Save results to CSV

            # for idx, name in enumerate(val_names):
            #     results = {
            #         "item_name": name,
            #         "optic_disc_dice": dice_scores["optic_disc"][idx],
            #         "optic_cup_dice": dice_scores["optic_cup"][idx],
            #         "optic_disc_assd": assd_scores["optic_disc"][idx],
            #         "optic_cup_assd": assd_scores["optic_cup"][idx],
            #     }
            #     results_df = pd.DataFrame([results])
            #     results_df.to_csv(
            #         "/home/ubuntu/PycharmProjects/FLAIR-1/cls_seg_test_dice_assd_results_0%.csv",
            #         mode="a",
            #         index=False,
            #         header=not os.path.exists(
            #             "/home/ubuntu/PycharmProjects/FLAIR-1/cls_seg_test_dice_assd_results_0%.csv",
            #         ),
            #     )


            val_batch_mean_iou = mean_iou(val_masks_hq, val_masks)
            val_mean_iou += val_batch_mean_iou

            val_preds_logits = val_preds_logits.cuda()
            val_logits = torch.stack([-val_preds_logits, val_preds_logits], dim=1) # 变成 (B, 2)， 二分类的logits计算，可以使用cls_evidence_loss

            val_cls_evidence = infer(val_logits)
            # -- use dirichlet distribution to get cls alpha -- #
            val_cls_alpha = val_cls_evidence + 1
            # -- get belief and uncertainty -- #
            # must keep dim keep it as (bs, 1) not (bs,)
            val_S = torch.sum(val_cls_alpha, dim=1, keepdim=True)
            # belief (bs, cls_class) image-level
            cls_belief = (val_cls_alpha - 1) / (val_S.expand(val_cls_alpha.shape))
            # uncertainty (bs, 1) image-level
            val_cls_uncertainty = 2 / val_S  # 类别数除总证据量

            # seg_uncetainty_cal
            seg_evidence = infer(val_masks_hq)  
            seg_alpha = seg_evidence + 1 
            # Calculate segmentation uncertainty
            val_seg_uncertainty = config.SEG_CLASS / torch.sum(seg_alpha, dim=1, keepdim=True)  # Shape: (bs, 1, h, w)
            # Calculate the uncertainty for each pixel
            # Visualize segmentation uncertainty for the first sample in the batch
            # Visualize ground truth mask, predicted mask, and segmentation uncertainty side by side
            # fig, axes = plt.subplots(1, 3, figsize=(24, 8))
            # Create a directory to save the output images
            output_path = os.path.join(output_dir, f"{val_names[0]}_seg_uncertainty_1.png")
            plt.imsave(output_path, val_seg_uncertainty[1, 0].cpu().numpy(), cmap='viridis')


            plt.figure(figsize=(8, 8))
            plt.imshow(val_seg_uncertainty[0, 0].cpu().numpy(), cmap='viridis')
            plt.colorbar(label='Uncertainty')
            plt.title("Segmentation Uncertainty")
            plt.axis('off')
            plt.show()


            val_probs = val_cls_alpha / torch.sum(val_cls_alpha, dim=1, keepdim=True)  # 将 alpha 转换为概率分布
            # 获取预测类别
            val_pred_labels = torch.argmax(val_probs, dim=1)  # 选择概率最大的类别
            total_val_labels.extend(val_cls_labels.cpu().numpy())
            total_val_preds.extend(val_pred_labels.cpu().numpy())
            item_name_ls.extend(val_names)
            cls_uncertainty_ls.extend(val_cls_uncertainty.squeeze().cpu().numpy())
            total_val_probs.extend(val_probs[:, 1].cpu().numpy())

        # Calculate accuracy and F1 score for the validation set
        val_mean_iou /= len(test_loader)
        total_val_preds = np.array(total_val_preds)
        total_val_labels = np.array(total_val_labels)
        total_val_probs = np.array(total_val_probs)
        # Calculate accuracy and F1 score for the validation set
        val_accuracy = accuracy_score(total_val_labels, total_val_preds)
        val_f1 = f1_score(total_val_labels, total_val_preds, average='weighted')
        print(val_mean_iou)
        return val_accuracy, val_f1, item_name_ls, cls_uncertainty_ls, total_val_labels, total_val_preds, val_mean_iou, total_val_probs
        
def main():
    test_loader = DataLoader(
    Refuge_Dataset(root_path=config.REFUGE_ROOT_PATH, data_type="Test"), batch_size=config.BATCH_SIZE, shuffle=False)
    model = CLS_SEG_Model().cuda()
    # pth_ls = [pth_1_path, pth_2_path, pth_3_path]
    pth_ls = ["/home/ubuntu/PycharmProjects/FLAIR-1/cls_seg_evi_weights/cls_seg_evi_epoch_101.pth"]
    
    
    pth_name_ls, test_acc_ls, test_f1_ls = [], [], []
    for pth in tqdm(pth_ls):
        pth_name = pth.split("/")[-1]
        pth_name_ls.append(pth_name)
        model.load_state_dict(torch.load(pth))
        model.cuda()
        test_acc, test_f1, names, uncertainties, true_labels, preds, val_mean_iou, total_val_probs = test(model, test_loader)
        print(f"{pth_name}, test_acc:{test_acc:.4f}, test_f1:{test_f1:.4f}")
        test_acc_ls.append(test_acc)
        test_f1_ls.append(test_f1)
        results = pd.DataFrame({
            "item_name": names,
            "uncertainty": uncertainties,
            "true_label": true_labels, 
            "pred_label": preds,
            "pred_probs": total_val_probs
         })
        results.to_csv(f"/home/ubuntu/PycharmProjects/FLAIR-1/cls_seg_test_uncertainty_results_0%.csv", mode="a", index=False)

    # res_df = pd.DataFrame({"model_name": pth_name_ls, "test_acc": test_acc_ls, "test_f1": test_f1_ls})
    # res_df.to_csv("/home/ubuntu/PycharmProjects/FLAIR-1/cls_test_res.csv", mode="a", index=False, header=False)



if __name__ == '__main__':

    os.environ["CUDA_VISIBLE_DEVICES"] = "0"
    main()








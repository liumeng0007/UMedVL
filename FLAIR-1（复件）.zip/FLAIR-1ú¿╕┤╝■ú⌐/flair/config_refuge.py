
# for optimizer
LEARNING_RATE = 0.0001
WEIGHT_DECAY = 1e-5

REFUGE_ROOT_PATH = "/home/ubuntu/桌面/UMLpaper_DATASET/refuge_glaucoma/Refuge_process_for_train"
BATCH_SIZE = 4

EPOCH = 300

TRAIN_NUM = 400
# steps
WHOLE_STEPS = (TRAIN_NUM / BATCH_SIZE) * EPOCH
CHANGE_EPOCH = 30
POWER = 0.9
BASE_STEPS = (TRAIN_NUM / BATCH_SIZE) * CHANGE_EPOCH - 1
# loss
CLS_ANNEALING_EPOCH = 50
SEG_ANNEALING_EPOCH = 50
SEG_CLASS = 3
CLS_CLASS = 2

VALID_EPOCH = 50
PATH_MODEL = "/home/ubuntu/PycharmProjects/MedCLIP/medclip/umedclip_pth_80glaucomma"
SEG_RESULT_PATH_OF_TEST = "/home/ubuntu/PycharmProjects/MedCLIP/medclip/umedclip_pth2/results"

